<?
$arModuleVersion = array(
	"VERSION" => "1.1.7",
	"VERSION_DATE" => "2025-07-20 17:41:00"
);
?>