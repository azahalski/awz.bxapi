<?
$arModuleVersion = array(
	"VERSION" => "1.1.6",
	"VERSION_DATE" => "2025-04-08 04:04:00"
);
?>