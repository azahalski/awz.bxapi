drop table if exists b_awz_bxapi_tokens;
drop table if exists b_awz_bxapi_apps;
drop table if exists b_awz_bxapi_handlers;
drop table if exists b_awz_bxapi_reviews;