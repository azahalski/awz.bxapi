<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.bxapi/admin/tokens_list.php");